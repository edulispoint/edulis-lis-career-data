# EduLIS LIS Career Hub — GitHub Actions edition

This edition keeps the public EduLIS website on InfinityFree and uses GitHub Actions to refresh a JSON recruitment feed every six hours. It does not require Flask, a Python server, or a database.

## Upload these files to `edulispoint/edulis-lis-career-data`

Upload the contents of this package while preserving the folders:
- `.github/workflows/update-feed.yml`
- `scripts/collect_opportunities.py`
- `docs/opportunities.json`
- `LIS_Career_Hub.html` (copy this to your InfinityFree website's Career folder)

## Configure GitHub
1. Open the repository: https://github.com/edulispoint/edulis-lis-career-data
2. Upload the three repository files/folders above (do not upload this README if you do not want it).
3. Open the repository's **Actions** tab.
4. If GitHub asks, click **I understand my workflows, go ahead and enable them**.
5. Select **Update LIS recruitment feed** and click **Run workflow**.
6. Wait for the run to finish successfully. The workflow also runs every six hours (UTC).

## Publish the webpage on InfinityFree
Upload `LIS_Career_Hub.html` to your existing site's `Career` directory, replacing the earlier Career Hub HTML page. Keep the EduLIS logo/image files and other site assets in their existing locations. If your actual page is in a different directory, adjust the logo and navigation paths as needed.

The page reads:
https://raw.githubusercontent.com/edulispoint/edulis-lis-career-data/main/docs/opportunities.json

## Important limitations
- This is automated discovery from Google News RSS search queries, not a complete official vacancy crawler.
- It may miss institutions, return irrelevant results, and cannot reliably extract deadlines from PDF notices.
- The publisher/source link is a lead; verify every vacancy, eligibility condition, deadline and application process on the recruiting institution's official notification.
- The scheduled workflow uses GitHub Actions. Scheduled jobs can be delayed or disabled by GitHub in some circumstances, so check the Actions tab occasionally.
- The public repository and JSON feed are public. Do not put personal data, credentials, or API keys in this repository.
